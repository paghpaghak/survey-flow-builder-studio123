import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Card } from '@/components/ui/card';
import { Page } from '@/types/survey';
import { cn } from '@/lib/utils';

interface DraggablePageCardProps {
  page: Page;
  selected: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

export function DraggablePageCard({
  page,
  selected,
  onClick,
  children
}: DraggablePageCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: page.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
    >
      <Card
        className={cn(
          "p-4 mb-2 cursor-move hover:bg-accent transition-colors",
          selected && "border-primary"
        )}
        onClick={onClick}
      >
        {children}
      </Card>
    </div>
  );
} 