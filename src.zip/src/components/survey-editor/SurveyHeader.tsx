import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface SurveyHeaderProps {
  title: string;
  description?: string;
}

export function SurveyHeader({ title, description }: SurveyHeaderProps) {
  const navigate = useNavigate();

  return (
    <div className="mb-6">
      <div className="flex items-center gap-4 mb-2">
        <Button variant="ghost" className="gap-1" onClick={() => navigate('/')}>
          <ArrowLeft className="h-4 w-4" /> Назад к опросам
        </Button>
        <h1 className="text-2xl font-bold">{title}</h1>
      </div>
      {description && (
        <p className="text-gray-500 ml-12">{description}</p>
      )}
    </div>
  );
} 