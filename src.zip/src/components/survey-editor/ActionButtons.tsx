import { Button } from '@/components/ui/button';
import { Eye, Plus } from 'lucide-react';

interface ActionButtonsProps {
  onPreviewClick: () => void;
  onAddQuestion: () => void;
  onAddPage: () => void;
  hasQuestions: boolean;
}

export function ActionButtons({
  onPreviewClick,
  onAddQuestion,
  onAddPage,
  hasQuestions
}: ActionButtonsProps) {
  return (
    <div className="flex gap-2 mb-4">
      <Button
        variant="outline"
        onClick={onPreviewClick}
        disabled={!hasQuestions}
        className="gap-2"
      >
        <Eye className="h-4 w-4" />
        Предпросмотр
      </Button>
      <Button
        variant="outline"
        onClick={onAddQuestion}
        className="gap-2"
      >
        <Plus className="h-4 w-4" />
        Добавить вопрос
      </Button>
      <Button
        variant="outline"
        onClick={onAddPage}
        className="gap-2"
      >
        <Plus className="h-4 w-4" />
        Добавить страницу
      </Button>
    </div>
  );
} 