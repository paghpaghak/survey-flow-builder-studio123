import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SurveyPreview } from '@/components/survey-preview/SurveyPreview';
import { Survey } from '@/types/survey';

interface SurveyPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  survey: Survey;
}

export function SurveyPreviewModal({
  isOpen,
  onClose,
  survey
}: SurveyPreviewModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[90vh]">
        <DialogHeader>
          <DialogTitle>Предпросмотр опроса</DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-auto">
          <SurveyPreview survey={survey} />
        </div>
      </DialogContent>
    </Dialog>
  );
} 